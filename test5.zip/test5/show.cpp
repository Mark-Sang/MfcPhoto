﻿// show.cpp: 实现文件
//

#include "stdafx.h"
#include "test2.h"
#include "show.h"
#include "afxdialogex.h"
#include "test2Dlg.h"

extern CString picturePath;

// show 对话框

IMPLEMENT_DYNAMIC(show, CDialogEx)
show::show(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_show, pParent)
{	
}

show::~show()
{
}

void show::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(show, CDialogEx)
	ON_BN_CLICKED(ID_SAVE, &show::OnBnClickedSave)
	ON_BN_CLICKED(IDC_DO, &show::OnBnClickedDo)
	ON_BN_CLICKED(ID_exit, &show::OnBnClickedexit)
	ON_BN_CLICKED(IDC_read, &show::OnBnClickedread)
END_MESSAGE_MAP()


// show 消息处理程序
void show::OnBnClickedSave()
{
	// TODO: 在此添加控件通知处理程序代码

	CString picture;
	CWnd* bmpShow = GetDlgItem(IDC_STATIC);
	CDC *pdc = bmpShow->GetDC();
	//CImage  imag;
	ATL::CImage imag;    //标识符以防不明确
	CRect rect;


	GetClientRect(&rect);        //获取画布大小
	bmpShow->GetWindowRect(&rect);
	imag.Create(rect.Width(), rect.Height(), 32);
	::BitBlt(imag.GetDC(), 0, 0, rect.Width(), rect.Height(), pdc->m_hDC, 0, 0, SRCCOPY);


	TCHAR szFilter[] = _T("jpg file(*.jpg)|*.jpg|bmp file(*.bmp)|*.bmp|所有文件(*.*)|*.*||");  //文件格式过滤
	   // 构造保存文件对话框    
	CFileDialog fileDlg(FALSE, _T("bmp"), _T("*.bmp"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter, this);
	fileDlg.m_ofn.lpstrTitle = _T("保存图像");  //保存对话窗口标题名
	//CString picturePath;
	if (IDOK == fileDlg.DoModal())  //按下确认键
	{
		picture = fileDlg.GetPathName();  //文件路径
	}


	HRESULT hResult = imag.Save(picture); //保存图片
	if (S_OK == hResult)
	{
		AfxMessageBox(_T("图片保存成功！"));
		AfxMessageBox(_T("文件保存至：") + picture);
	}
	else
	{
		AfxMessageBox(_T("失败！"));
	}
	ReleaseDC(pdc);
	imag.ReleaseDC();
	
}




void show::OnBnClickedexit()
{
	// TODO: 在此添加控件通知处理程序代码
	exit(0);
}

void show::OnBnClickedDo()
{
	// TODO: 在此添加控件通知处理程序代码
	
	CImage c;
	CPoint pt;
	CRect   rect;
	BYTE r, g, b;

	c.Load(picturePath);
	int w = c.GetWidth(); 
	int h = c.GetHeight();
	for (int i = 0; i < w; i++)
	for (int j = 0; j < h; j++)
	{
			COLORREF cc = c.GetPixel(i,j);//COLORREF其实就是int类型，也就是RGB的0-255值﻿
			r = GetRValue(cc);
			g = GetGValue(cc);
			b = GetBValue(cc);
			r = g = b = (r+g+b) / 3;	
			c.SetPixel(i, j, RGB(r,g,b));

	}

	GetDlgItem(IDC_STATIC)->GetWindowRect(&rect);
	CWnd *pWnd = NULL;
	pWnd = GetDlgItem(IDC_STATIC);//获取控件句柄  
	pWnd->GetClientRect(&rect);//获取句柄指向控件区域的大小  
	CDC *pDc = NULL;
	pDc = pWnd->GetDC();//获取picture的DC  
	c.Draw(pDc->m_hDC, rect);//将图片绘制到picture表示的区域内  
	ReleaseDC(pDc);
	


}


void show::OnBnClickedread()
{
	BYTE *pBmpData;             //图像数据
	BITMAPINFO *pBmpInfo;       //记录图像细节
	BITMAPINFOHEADER bmpInfo;   //信息头
	BITMAPFILEHEADER bmpHeader; //文件头
	CFile bmpFile;              //记录打开文件
	// TODO: 在此添加控件通知处理程序代码
	//以只读的方式打开文件 读取bmp图片各部分 bmp文件头 信息 数据
	if (!bmpFile.Open(picturePath, CFile::modeRead | CFile::typeBinary))
		return;
	if (bmpFile.Read(&bmpHeader, sizeof(BITMAPFILEHEADER)) != sizeof(BITMAPFILEHEADER))
		return;
	if (bmpFile.Read(&bmpInfo, sizeof(BITMAPINFOHEADER)) != sizeof(BITMAPINFOHEADER))
		return;
	pBmpInfo = (BITMAPINFO *)new char[sizeof(BITMAPINFOHEADER)];
	//为图像数据申请空间
	memcpy(pBmpInfo, &bmpInfo, sizeof(BITMAPINFOHEADER));
	DWORD dataBytes = bmpHeader.bfSize - bmpHeader.bfOffBits;
	pBmpData = (BYTE*)new char[dataBytes];
	bmpFile.Read(pBmpData, dataBytes);
	bmpFile.Close();

	//显示图像
	CWnd *pWnd = GetDlgItem(IDC_STATIC); //获得pictrue控件窗口的句柄
	CRect rect;
	pWnd->GetClientRect(&rect); //获得pictrue控件所在的矩形区域
	CDC *pDC = pWnd->GetDC(); //获得pictrue控件的DC
	pDC->SetStretchBltMode(COLORONCOLOR);
	StretchDIBits(pDC->GetSafeHdc(), 0, 0, rect.Width(), rect.Height(), 0, 0,
	bmpInfo.biWidth, bmpInfo.biHeight, pBmpData, pBmpInfo, DIB_RGB_COLORS, SRCCOPY);

}
